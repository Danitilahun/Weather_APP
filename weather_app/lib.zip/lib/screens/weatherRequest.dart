import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:weather_app/model/model.dart';

Future<List<WeatherData>> fetchWeatherData(
    double latitude, double longitude) async {
  final apiKey = 'a88bc0d22118d14b4a87c811d502d9ca';
  final apiUrl = 'https://api.openweathermap.org/data/2.5/forecast?';
  final url =
      Uri.parse('$apiUrl' + 'lat=$latitude&lon=$longitude&appid=$apiKey');

  final response = await http.get(url);

  if (response.statusCode == 200) {
    final jsonData = json.decode(response.body);
    final List<dynamic> responseList =
        jsonData['response']; // Assuming the response is a list
    final List<WeatherData> weatherDataList = [];

    for (final item in responseList) {
      final weatherData = WeatherData.fromJson(item);
      weatherDataList.add(weatherData);
    }
    return weatherDataList;
  } else {
    throw Exception('Failed to fetch weather data');
  }
}
